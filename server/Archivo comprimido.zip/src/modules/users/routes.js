const express = require('express')

const router = express.Router();
const requests = require('../../red/requests')
const controller = require('./controller')

router.get('/', (req, res) => {
    const getAllUsers = controller.getAllUsers().then((items) => {
        requests.success(req, res, items, 200)
    })
})

module.exports = router